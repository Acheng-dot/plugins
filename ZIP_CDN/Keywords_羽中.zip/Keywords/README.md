### Typecho关键词链接插件Keywords
2023年12月30日更新至**v1.0.9**: 
- 解决php8.2一处报错
- 支持typecho1.2.1

2018年6月24日更新至**v1.0.8**: 
- 增加链接标记参数支持
- 增加分类内链与标记项
- 修正版本空字符等bug

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/keywords-for-typecho
